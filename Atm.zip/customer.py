class Customer:
    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name

    def transact(self, account, amount):
        account.update(amount)

    def __str__(self):
        return self.__name

    
