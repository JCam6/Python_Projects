class Account:
    def __init__(self, name, balance):
        self.__name = name
        self.__balance = balance

    def get_name(self):
        return self.__name

    def get_balance(self):
        return self.__balance
    
    def convert(self, currency, amount):
        if (currency == "USD"):
            return amount
        elif (currency == "EUR"):
            amount = amount / 0.86
            return int(amount)
        elif (currency == "CAD"):
            amount = amount / 1.3
            return int(amount)
    
    def update(self, amount_in_usd):
        self.__balance = self.__balance + amount_in_usd
        return self.__balance

    def __str__(self):
        return (self.__name + str(self.__balance))